package farm.stock.count;

public class HowMany {
    public int getCount(){
        return 11;
    }    
}
