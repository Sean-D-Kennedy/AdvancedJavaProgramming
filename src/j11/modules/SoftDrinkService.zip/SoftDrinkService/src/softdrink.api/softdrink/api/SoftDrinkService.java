package softdrink.api;

// The Service Contract
// This interface is what binds/links the consumers and providers.
public interface SoftDrinkService{
     String getSize();
}
