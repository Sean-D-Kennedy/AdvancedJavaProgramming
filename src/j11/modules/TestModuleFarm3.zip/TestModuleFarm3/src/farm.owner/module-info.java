module farm.owner {
    exports farm.owner;

    requires transitive farm.animals;
}
