module farm.vet {
    exports farm.vet;

    requires farm.owner;
}
