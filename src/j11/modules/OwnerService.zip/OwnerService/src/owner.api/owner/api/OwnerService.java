package owner.api;

// The Service Contract
// This interface is what binds/links the consumers and providers.
public interface OwnerService{
  public String getAnimal(String tag);
}
