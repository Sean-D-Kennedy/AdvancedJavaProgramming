package sample.typing;

import text.utils.Utils;

public class Main{
  public static void main(String[] args){
    	String uppercase = Utils.upper("this is lower");
	    System.out.println(uppercase);
  }
}
