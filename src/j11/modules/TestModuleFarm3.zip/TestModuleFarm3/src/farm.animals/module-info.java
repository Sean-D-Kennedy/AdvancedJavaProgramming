module farm.animals {
    exports farm;
    exports farm.cattle;
}
