package farm.stock.sale;

import farm.stock.count.HowMany;

public class SellThem {
    public static void main(String[] args) {
        HowMany hm = new HowMany();
        System.out.println(hm.getCount());
    }
}
