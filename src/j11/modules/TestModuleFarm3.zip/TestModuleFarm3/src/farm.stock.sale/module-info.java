open module farm.stock.sale {
   // dependencies clearly stated
   requires farm.stock.count;
//   opens farm.stock.count;
}
