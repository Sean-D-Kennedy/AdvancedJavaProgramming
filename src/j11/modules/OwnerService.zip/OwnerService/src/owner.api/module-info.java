module owner.api {
    // We need to export the service contract
    // so that consumers and providers are aware of it.
    exports owner.api;
}
