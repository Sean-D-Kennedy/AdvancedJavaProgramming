module sample.typing {
    requires text.utils;
}
