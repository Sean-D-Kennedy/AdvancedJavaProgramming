package softdrink.extralarge;

import softdrink.api.SoftDrinkService;

public class ExtraLargeSoftDrinkService implements SoftDrinkService{
    @Override
     public String getSize(){
       return "Extra Large";
     }
}
