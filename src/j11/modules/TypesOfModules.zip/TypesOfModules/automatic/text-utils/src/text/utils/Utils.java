package text.utils;

public class Utils{
  public static String upper(String in){
    return in.toUpperCase();

  }
}
