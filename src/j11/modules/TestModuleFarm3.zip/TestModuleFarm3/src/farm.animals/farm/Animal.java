package farm;

public class Animal{
  private String tagNumber;

  public Animal(String tagNumber){
    this.tagNumber = tagNumber;
  }
  public String getTagNumber(){
    return tagNumber;
  }
}
